﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace XXL_Correcoes_Internas
{
	internal class LeituraEEscrita
	{
		public string TXT(string caminho_args) //Metodo que le os arquivos para conversao
		{
			try
			{
				//Variaveis
				string[] arquivos = Directory.GetFiles(caminho_args, "*.TXT");				
				List<string> lista_material_original = new List<string>();

				//Calculos
				foreach (var item in arquivos)
				{
					string nomeArquivo = item.ToString().Replace("TXT", "INI"); //Nome

					StreamReader leituraTXT = new StreamReader(item); //Leitura, listagem, escrita
					{
						while (!leituraTXT.EndOfStream)
						{
							string leituraLinha = leituraTXT.ReadLine();
							lista_material_original.Add(leituraLinha);
						}

						StreamWriter escritaINI = new StreamWriter(nomeArquivo);
						{
							escritaINI.WriteLine("[MATERIAL]");

							for (int i = 0; i < lista_material_original.Count; i++)
							{
								int contador = i+1;

								escritaINI.WriteLine(contador + "=" + lista_material_original[i]);
							}
						}
						escritaINI.Close();
						escritaINI.Dispose();
					}
					leituraTXT.Close();
					leituraTXT.Dispose();

					File.Delete(item);
				}

				return caminho_args;
			}
			catch (Exception e)
			{
				MessageBox.Show(e.ToString(), "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				throw;
			}
		}
	}
}
