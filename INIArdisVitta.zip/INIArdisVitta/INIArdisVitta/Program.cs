﻿using System;
using System.IO;
using System.Windows.Forms;
using XXL_Correcoes_Internas;

namespace INIArdisVitta
{
	internal class Program
	{
		static void Main(string[] args)
		{
			//CHAMAR("NomeCompletoApp" ; "NomeCompletoPastaSemEspaco\*.*")

			DateTime dataatual = DateTime.Now;
			DateTime datavencimento = new DateTime(year: 2030, 12, 31, 23, 59, 00);
			int comparativodata = DateTime.Compare(dataatual, datavencimento);
			LeituraEEscrita NovaLeitura = new LeituraEEscrita();

			if (comparativodata <= 0)
			{
				if (args.Length > 0)
				{
					for (int i = 0; i < args.Length; i++)
					{
						string somentepasta = Path.GetDirectoryName(args[i]);
						NovaLeitura.TXT(somentepasta);
					}
				}
				else if (args.Length <= 0)
				{
					string pasta = Directory.GetCurrentDirectory();
					NovaLeitura.TXT(pasta);
				}
			}
			else
			{
				MessageBox.Show("Sem licença!\nEntrar em contato com o Desenvolvedor - TopSolid\n(43) 9 9919-2981", "Atenção!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
			}
		}
	}
}


#region Temp
/*	
*/
#endregion